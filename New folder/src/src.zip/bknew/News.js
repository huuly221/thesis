import React, { Component } from 'react';
import { Grid, Row, Col, Carousel } from 'react-bootstrap';
import './new.css'
import Slider from 'react-slick';

import Pagi from './pagination.js';
export default class News extends Component {
  render() {
    
    return (
            <div className="BKEvent">
                <Grid>
                    

                    <div className="articles">
                        <header className="all-Event">
                            Tin Tức Mới Nhất
                        </header>
                        <div className="article">
                        <div className="article-left">
                            <a href="single.html"><img src="images/article1.jpg" /></a>
                        </div>
                        <div className="article-center">
                            <div className="article-title">
                            <p>On Feb 25, 2015 <a className="span_link" href="#"><span className="glyphicon glyphicon-comment" />0 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-eye-open" />104 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-thumbs-up" />52</a></p>
                            <a className="title" href="single.html"> The section of the mass media industry that focuses on presenting</a>
                            </div>
                            <div className="article-text">
                            <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                            
                            <div className="clearfix" />
                            </div>
                        </div>
                       

                        <div className="clearfix" />
                        </div>
                        <div className="article">
                            <div className="article-left">
                                <a href="single.html"><img src="images/article1.jpg" /></a>
                            </div>
                            <div className="article-center">
                                <div className="article-title">
                                <p>On Apr 11, 2015 <a className="span_link" href="#"><span className="glyphicon glyphicon-comment" />2 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-eye-open" />54 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-thumbs-up" />18</a></p>
                                <a className="title" href="single.html">Contrary to popular belief, Lorem Ipsum is not simply random</a>
                                </div>
                                <div className="article-text">
                                <p>It is a long established fact that a reader will be distracted by the readable.....</p>
                                
                                <div className="clearfix" />
                                </div>
                            </div>
                           
                            <div className="clearfix" />
                        </div>
                        <div className="article">
                        <div className="article-left">
                            <a href="single.html"><img src="images/article3.jpg" /></a>
                        </div>
                        <div className="article-center">
                            <div className="article-title">
                            <p>On Feb 25, 2015 <a className="span_link" href="#"><span className="glyphicon glyphicon-comment" />0 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-eye-open" />104 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-thumbs-up" />52</a></p>
                            <a className="title" href="single.html"> The section of the mass media industry that focuses on presenting</a>
                            </div>
                            <div className="article-text">
                            <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                            
                            <div className="clearfix" />
                            </div>
                        </div>
                        
                        <div className="clearfix" />
                        </div>
                        <div className="article">
                        <div className="article-left">
                            <a href="single.html"><img src="images/article4.jpg" /></a>
                        </div>
                        <div className="article-center">
                            <div className="article-title">
                            <p>On Feb 25, 2015 <a className="span_link" href="#"><span className="glyphicon glyphicon-comment" />0 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-eye-open" />104 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-thumbs-up" />52</a></p>
                            <a className="title" href="single.html"> The section of the mass media industry that focuses on presenting</a>
                            </div>
                            <div className="article-text">
                            <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                            
                            <div className="clearfix" />
                            </div>
                        </div>
                        
                        <div className="clearfix" />
                        </div>
                        <div className="article">
                        <div className="article-left">
                            <a href="single.html"><img src="images/article1.jpg" /></a>
                        </div>
                        <div className="article-center">
                            <div className="article-title">
                            <p>On Feb 25, 2015 <a className="span_link" href="#"><span className="glyphicon glyphicon-comment" />0 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-eye-open" />104 </a><a className="span_link" href="#"><span className="glyphicon glyphicon-thumbs-up" />52</a></p>
                            <a className="title" href="single.html"> The section of the mass media industry that focuses on presenting</a>
                            </div>
                            <div className="article-text">
                            <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                            
                            <div className="clearfix" />
                            </div>
                        </div>
                        
                        <div className="clearfix" />
                        </div>
                    </div>
                    <div className="pagination-move" >
                    <Pagi/>
                    </div>
                </Grid>
            </div>
    );
  }
}        