import React, { Component } from 'react';
import { Navbar,NavItem,NavDropdown,MenuItem, Nav,FormGroup,FormControl, Grid, Row, Col, Carousel } from 'react-bootstrap';
import NavbarMenu from '../navbar2/navbar';
import RightBar from '../right-bar/right-bar';
import Carousels from '../carousel/carousel';
import BKEvent from '../BKEvent/BKEvent';
import Documents from '../documents/documents';
import BKNews from '../BKNews/BKNews';
import Footer from '../footer/footer';
import MapKhoa from '../contact/contact.js';
import logoBK from '../image/logo.png';
import search from '../image/svg-search.gif';
import Login from '../userlogin/login.js';
import News from '../bknew/News.js';
import './Routers.css';

//import NavbarMenu from '../menu-navbar/navbar';



import { BrowserRouter as Router, Route, Link } from "react-router-dom";

class Routers extends Component {
    constructor(props) {
        super(props); 
        this.state = {  };
   
    }
   
    render() {
        return (
            <Router>
            
                <div>
                    <NavbarMenu />
                    <Grid fluid="true">
                   
                    
                      <Route  path="/Contact" component={Contact} />
                         
                    </Grid>
                    <Route exact path="/" component={Home} />
                    <Grid>
                   
                      <Route path="/Sukien" component={Events} />
                      
                    
                         
                    </Grid>
                    <Route path="/Tintuc" component={Tintuc} />

                    <Route path="/Vanban" component={Vanban} />
                    <Route path="/Dangnhap" component={Log} />
                    <Footer />
                </div>
            </Router>
        );
    }
}

  const Events = () => (
    <div className="clear-component">
      <BKEvent 
      url='http://localhost:3001/api/bkevent'
      pollInterval={2000} />
    </div>
  );
  const Tintuc = () => (
    <div className="clear-component">
      <News/>
    </div>
  );
  const Vanban = () => (
    <div className="clear-component">
      <Documents 
      url='http://localhost:3001/api/bkdocument'
      pollInterval={2000} />
    </div>
  );
  const Log = () => (
    <div className="clear-component">
      <Login
    url='http://localhost:3001/api/user'
    pollInterval={2000} />
    </div>
  );
  const Contact = () => (
    <div className="clear-component">
        <MapKhoa isMarkerShown/>
        <div className="contact_grid">
        <div className="col-md-8 contact-top">
          <h3>Gửi Lời Nhắn Cho Chúng Tôi</h3>
          <p className="contact_msg">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy</p>
          <form>
            <div className="to">
              <input type="text" className="text" defaultValue="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}" />
              <input type="text" className="text" defaultValue="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" style={{marginLeft: 20}} />
              <input type="text" className="text" defaultValue="Subject" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Subject';}" style={{marginLeft: 20}} />
            </div>
            <div className="text">
              <textarea onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}" defaultValue={"Message:"} />
            </div>
            <div className="form-submit1">
              <input name="submit" type="submit" id="submit" defaultValue="Gửi Lời Nhắn Cho Chúng Tôi " /><br />
              <p className="m_msg">Make sure you put a valid email</p>
            </div>
            <div className="clearfix"> </div>
          </form>
        </div>
        <div className="col-md-4 contact-top_right">
          <h3>Thông Tin Liên Hệ</h3>
          <p>diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.</p>
          <ul className="contact_info">
            <li><span>+1900-235-2456</span></li>
            <li><span className="msg"><a href="malito:mail@example.com">mail(at)example.com</a></span></li>
          </ul>
        </div>
        <div className="clearfix" />
      </div>
      
      
    </div>
  );
  const Home = ({ match }) => (
    <div>
      
      <Grid fluid="true">
                    
                        <Row>
                                <Col xs={12} md={8}>
                                <Route
                                    exact
                                    path={match.url}
                                    render={() => <div className="clear-component"> <Carousels /></div>}
                                    />
                                </Col>
                                <Col xs={12} md={4}>
                                    <RightBar />
                                </Col>
                        </Row>
                        
                    </Grid>
                    <div className="clearfix-page"></div>
                    <BKNews />
    
    
   
    </div>
  );
  
  const Home1 = ({ match }) => (
    <div>
    <Carousels />
  
  
</div>
  );
 
export default Routers;
