import React from 'react';
import {connect} from 'react-redux';
import SignIn from './signin.js';
class AccountInfo extends React.Component{
    logOut(e){
            e.preventDefault();
            sessionStorage.removeItem("username");
            var {dispatch} = this.props;
           dispatch({type: 'LOG_OUT'});
         }
  render(){
    var {username} = this.props;
    var xhtml = sessionStorage.getItem("username")? <SignIn/>:<AccountInfo/>
    return (
      <div>
        <h1>This is Account</h1>
        <p>Username: {sessionStorage.getItem("username")}</p>
        <a href="#" onClick={this.logOut.bind(this)}>Log out</a>
      </div>
    )
  }
}

export default  connect(function (state){
  return {username: state.username};
})(AccountInfo);