import React, { Component } from 'react';

export default class Transaction extends Component{
render(){
   return (
     <div>
      <h1>This is Transaction</h1>
    </div>
   )
  }
}

